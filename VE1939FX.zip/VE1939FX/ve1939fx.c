/*
 * main.c
 */

#include <Dsplib.h>
#include <usbstk5515.h>
#include <AIC_func.h>
#include <usbstk5515_interrupts.h>
#include <stdint.h>
#include <stdio.h>

extern volatile int16_t k1, k2, k3, k4, k5, k6, k7, k8, k9;

void C55_setup();

int main(void) {
	

	C55_setup();
	_enable_interrupts();




	while(1){
		printf("K1 value: %d\n", k1);
		printf("K2 value: %d\n", k2);

	}

	return 0;
}
